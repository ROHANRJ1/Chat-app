package com.chatapp.start.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.chatapp.start.service.dto.GroupMessageDTO;

@Entity
@Table(name = "group_message")
public class GroupMessage implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "message")
	private String message;
	
	@Column(name = "send_on")
	private LocalDateTime sendOn;
	
	@ManyToOne
	private User user;
	
	/*Consider only one group*/
	@OneToOne
	private ChatGroup chatGroup;	

	public GroupMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GroupMessage(GroupMessageDTO groupMessageDTO) {
		super();
		this.id = groupMessageDTO.getId();
		this.message = groupMessageDTO.getMessage();
		this.sendOn = groupMessageDTO.getSendOn();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getSendOn() {
		return sendOn;
	}

	public void setSendOn(LocalDateTime sendOn) {
		this.sendOn = sendOn;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ChatGroup getChatGroup() {
		return chatGroup;
	}

	public void setChatGroup(ChatGroup chatGroup) {
		this.chatGroup = chatGroup;
	}
	
}
