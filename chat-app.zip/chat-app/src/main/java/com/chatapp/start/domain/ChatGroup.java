package com.chatapp.start.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "chat_group")
public class ChatGroup implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "group_name")
	private String groupName;
	
	@Column(name = "group_created_on")
	private LocalDateTime groupCreatedOn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public LocalDateTime getGroupCreatedOn() {
		return groupCreatedOn;
	}

	public void setGroupCreatedOn(LocalDateTime groupCreatedOn) {
		this.groupCreatedOn = groupCreatedOn;
	}
	

}
