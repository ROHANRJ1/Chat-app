package com.chatapp.start.service;

import com.chatapp.start.domain.ChatGroup;

public interface ChatGroupService {

	ChatGroup save(ChatGroup chatGroup);
}
