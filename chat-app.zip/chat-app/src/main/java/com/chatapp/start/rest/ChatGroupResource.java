package com.chatapp.start.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chatapp.start.domain.ChatGroup;
import com.chatapp.start.service.ChatGroupService;

@RestController
@RequestMapping("/api")
public class ChatGroupResource {
	
	@Autowired
	ChatGroupService chatGroupService;	
	
	@PostMapping("/chat-group")
	public ResponseEntity<ChatGroup> saveChatGroupInfo(@RequestBody ChatGroup chatGroup) {
		ChatGroup savedChatGroup = chatGroupService.save(chatGroup);
		return ResponseEntity.ok().body(savedChatGroup);
	}

}
