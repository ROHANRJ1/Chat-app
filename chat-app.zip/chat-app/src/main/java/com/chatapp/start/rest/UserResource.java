package com.chatapp.start.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chatapp.start.domain.User;
import com.chatapp.start.service.UserService;

@RestController
@RequestMapping("/api")
public class UserResource {
	
	@Autowired
	UserService userService;	
	
	@PostMapping("/users")
	public ResponseEntity<User> saveUserInfo(@RequestBody User user) {
		User savedUser = userService.save(user);
		return ResponseEntity.ok().body(savedUser);
	}

}
