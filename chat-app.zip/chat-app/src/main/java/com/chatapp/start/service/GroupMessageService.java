package com.chatapp.start.service;

import java.util.List;

import com.chatapp.start.service.dto.GroupMessageDTO;

public interface GroupMessageService {
	
	GroupMessageDTO sendMessage(GroupMessageDTO groupMessageDTO);
	
	List<GroupMessageDTO> getChatMessages(Long groupId);

}
