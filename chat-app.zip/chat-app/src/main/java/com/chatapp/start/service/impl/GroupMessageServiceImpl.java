package com.chatapp.start.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chatapp.start.domain.ChatGroup;
import com.chatapp.start.domain.GroupMessage;
import com.chatapp.start.service.GroupMessageService;
import com.chatapp.start.service.dto.GroupMessageDTO;
import com.chatapp.start.service.repository.ChatGroupRepository;
import com.chatapp.start.service.repository.GroupMessageRepository;
import com.chatapp.start.service.repository.UserRepository;

@Service
public class GroupMessageServiceImpl implements GroupMessageService {
	
	@Autowired
	GroupMessageRepository groupMessageRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ChatGroupRepository chatGroupRepository;

	/*Send message to group*/
	@Override
	public GroupMessageDTO sendMessage(GroupMessageDTO groupMessageDTO) {
		groupMessageDTO.setSendOn(LocalDateTime.now());
		GroupMessage groupMessage = new GroupMessage(groupMessageDTO);		
		
		/*Exceptional Handling for Optional Check if not present is pending*/
		
		groupMessage.setUser(userRepository.findById(groupMessageDTO.getId()).get());
		groupMessage.setChatGroup(chatGroupRepository.findById(groupMessageDTO.getChatGroupId()).get());
		
		groupMessage = groupMessageRepository.save(groupMessage);
		return new GroupMessageDTO(groupMessage);
	}

	@Override
	public List<GroupMessageDTO> getChatMessages(Long groupId) {
		Optional<ChatGroup> chatGroup = chatGroupRepository.findById(groupId);
		List<GroupMessage> groupMessages = groupMessageRepository.findAllByChatGroup(chatGroup.get());
		return !groupMessages.isEmpty() ? mapGroupMessages(groupMessages) : new ArrayList<GroupMessageDTO>();
	}

	private List<GroupMessageDTO> mapGroupMessages(List<GroupMessage> groupMessages) {
		return groupMessages.stream()
	            .filter(Objects::nonNull)
	            .map(this::toDTO)
	            .collect(Collectors.toList());
	}
	
	private GroupMessageDTO toDTO(GroupMessage groupMessage) {
		return new GroupMessageDTO(groupMessage);
	}

}
