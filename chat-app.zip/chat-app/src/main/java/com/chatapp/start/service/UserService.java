package com.chatapp.start.service;

import com.chatapp.start.domain.User;

public interface UserService {
	
	User save(User user);

}
