package com.chatapp.start.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chatapp.start.domain.ChatGroup;
import com.chatapp.start.service.ChatGroupService;
import com.chatapp.start.service.repository.ChatGroupRepository;

@Service
public class ChatGroupServiceImpl implements ChatGroupService {
	
	@Autowired
	ChatGroupRepository chatGroupRepository;

	/*Save chat-group details*/
	@Override
	public ChatGroup save(ChatGroup chatGroup) {
		// TODO Auto-generated method stub
		return chatGroupRepository.save(chatGroup);
	}

}
