package com.chatapp.start.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chatapp.start.service.GroupMessageService;
import com.chatapp.start.service.dto.GroupMessageDTO;

@RestController
@RequestMapping("/api")
public class GroupMessageResource {
	
	@Autowired
	GroupMessageService groupMessageService;	
	
	@PostMapping("/message/send")
	public ResponseEntity<GroupMessageDTO> sendMessages(@RequestBody GroupMessageDTO groupMessageDTO) {
		GroupMessageDTO savedGroupMessage = groupMessageService.sendMessage(groupMessageDTO);
		return ResponseEntity.ok().body(savedGroupMessage);
	}
	
	@GetMapping("message/receive")
	public ResponseEntity<List<GroupMessageDTO>> getMessage(@PathVariable Long groupId) {
		List<GroupMessageDTO> groupMessages = groupMessageService.getChatMessages(groupId);
		return ResponseEntity.ok().body(groupMessages);
	}

}
