package com.chatapp.start.service.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.chatapp.start.domain.GroupMessage;
import com.fasterxml.jackson.annotation.JsonFormat;

public class GroupMessageDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String message;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm", shape = JsonFormat.Shape.STRING)
	private LocalDateTime sendOn;
	
	private Long userId;
	
	private Long chatGroupId;
	
	private String userName;
	
	private String groupName;

	public GroupMessageDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GroupMessageDTO(GroupMessage groupMessage) {
		super();
		this.id = groupMessage.getId();
		this.message = groupMessage.getMessage();
		this.sendOn = groupMessage.getSendOn();
		this.userId = groupMessage.getUser().getId();
		this.chatGroupId = groupMessage.getChatGroup().getId();
		this.userName = groupMessage.getUser().getUsername();
		this.groupName = groupMessage.getChatGroup().getGroupName();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getSendOn() {
		return sendOn;
	}

	public void setSendOn(LocalDateTime sendOn) {
		this.sendOn = sendOn;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getChatGroupId() {
		return chatGroupId;
	}

	public void setChatGroupId(Long chatGroupId) {
		this.chatGroupId = chatGroupId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


}
